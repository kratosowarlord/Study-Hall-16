ColumnNO.	Name			DataType
Column1:	AthleteName		STRING
Column2: 	Age				INT
Column3:	Country			STRING
Column4:	Year			INT
Column5:	Closing_Date	STRING
Column6:	Sport			STRING
Column7:	Gold_Medals		INT
Column8:	Silver_Medals	INT
Column9:	Bronze _Medals	INT
Column10:	Total_ Medals	INT
The sample dataset is made in reference to real life Olympic competition. But it is not an actual data. It has been modified and published in terms to learning only.